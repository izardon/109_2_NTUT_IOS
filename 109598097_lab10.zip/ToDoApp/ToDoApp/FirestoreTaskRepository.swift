//
//  FirestoreTaskRepository.swift
//  ToDoApp
//
//  Created by 詹昆宬 on 2021/5/31.
//

import Foundation
import Firebase

class FirestoreTaskRepository: ObservableObject{
    
    
}
