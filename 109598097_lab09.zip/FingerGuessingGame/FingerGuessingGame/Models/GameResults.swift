//
//  GameResults.swift
//  FingerGuessingGame
//
//  Created by 詹昆宬 on 2021/5/19.
//

import Foundation

enum GameResult {
    case win
    case lose
    case tie
}
