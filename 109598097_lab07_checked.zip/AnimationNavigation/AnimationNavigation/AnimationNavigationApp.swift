//
//  AnimationNavigationApp.swift
//  AnimationNavigation
//
//  Created by 詹昆宬 on 2021/5/5.
//

import SwiftUI

@main
struct AnimationNavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
