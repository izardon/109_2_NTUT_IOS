//
//   ProductionGroupView.swift
//  AnimationNavigation
//
//  Created by 詹昆宬 on 2021/5/5.
//

import SwiftUI

struct _ProductionGroupView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct _ProductionGroupView_Previews: PreviewProvider {
    static var previews: some View {
        _ProductionGroupView()
    }
}
