//
//  ModelBindingApp.swift
//  ModelBinding
//
//  Created by 詹昆宬 on 2021/5/10.
//

import SwiftUI

@main
struct ModelBindingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
